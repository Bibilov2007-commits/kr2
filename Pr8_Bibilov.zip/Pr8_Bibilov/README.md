# Практическая работа №8
Бибилов Марат, ЭФБО-08-25, зачётка 25Т0751. Вариант 4.

Запуск из папки проекта:
```
javac -encoding UTF-8 -d out src/*.java
java -cp out Main
java -cp out SelfCheck
```
