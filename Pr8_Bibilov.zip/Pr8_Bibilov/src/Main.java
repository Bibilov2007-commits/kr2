import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        BusinessTripService service = new BusinessTripService();
        Employee employee = new Employee("1", "Марат Бибилов");
        BusinessTrip trip = service.create("100", employee, LocalDate.of(2026, 10, 10), LocalDate.of(2026, 10, 15));
        System.out.println("Заявка: " + trip.getId() + ", статус: " + trip.getStatus());
        trip.submit();
        trip.approve();
        trip.complete(LocalDate.of(2026, 10, 16));
        System.out.println("Новый статус: " + trip.getStatus());
        System.out.println("Завершённых заявок: " + service.findByStatus(TripStatus.COMPLETED).size());
    }
}
