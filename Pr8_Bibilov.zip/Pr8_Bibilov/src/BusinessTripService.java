import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BusinessTripService {
    private List<BusinessTrip> trips = new ArrayList<>();

    public BusinessTrip create(String id, Employee employee, LocalDate start, LocalDate end) {
        for (BusinessTrip trip : trips) {
            if (trip.getId().equals(id)) throw new IllegalArgumentException("Заявка уже существует");
        }
        BusinessTrip trip = new BusinessTrip(id, employee, start, end);
        trips.add(trip);
        return trip;
    }
    public List<BusinessTrip> findByStatus(TripStatus status) {
        if (status == null) throw new IllegalArgumentException("Нет статуса");
        List<BusinessTrip> found = new ArrayList<>();
        for (BusinessTrip trip : trips) {
            if (trip.getStatus() == status) found.add(trip);
        }
        return found;
    }
}
