public class Employee {
    private String id;
    private String fullName;

    public Employee(String id, String fullName) {
        if (id == null || id.trim().isEmpty() || fullName == null || fullName.trim().isEmpty()) {
            throw new IllegalArgumentException("Не заполнен сотрудник");
        }
        this.id = id;
        this.fullName = fullName;
    }
    public String getId() { return id; }
    public String getFullName() { return fullName; }
}
