import java.time.LocalDate;

public class SelfCheck {
    private static int count = 0;
    private static int ok = 0;
    private static Employee employee = new Employee("1", "Петров Петр");

    private static BusinessTrip make() {
        return new BusinessTrip("1", employee, LocalDate.of(2026, 10, 10), LocalDate.of(2026, 10, 15));
    }
    private static void check(boolean good, String name) {
        count++;
        if (good) { ok++; System.out.println("OK " + name); }
        else System.out.println("FAIL " + name);
    }
    private static void error(Runnable r, Class<?> type, String name) {
        try { r.run(); check(false, name); }
        catch (Exception e) { check(type.isInstance(e), name); }
    }
    public static void main(String[] args) {
        BusinessTrip a = make();
        check(a.getStatus() == TripStatus.DRAFT, "начальный статус");
        a.submit(); check(a.getStatus() == TripStatus.SUBMITTED, "отправка");
        error(a::submit, IllegalStateException.class, "повторная отправка");
        a.approve(); check(a.getStatus() == TripStatus.APPROVED, "согласование");
        error(a::approve, IllegalStateException.class, "повторное согласование");
        error(() -> a.complete(LocalDate.of(2026,10,15)), IllegalStateException.class, "последний день");
        a.complete(LocalDate.of(2026,10,16)); check(a.getStatus() == TripStatus.COMPLETED, "после окончания");
        error(a::cancel, IllegalStateException.class, "отмена завершённой");
        BusinessTrip b = make(); b.submit();
        error(() -> b.reject("Очень коротко"), IllegalArgumentException.class, "короткая причина");
        check(b.getStatus() == TripStatus.SUBMITTED, "статус не испортился");
        String reason24 = "123456789012345678901234";
        error(() -> b.reject(reason24), IllegalArgumentException.class, "24 символа");
        b.reject("1234567890123456789012345");
        check(b.getStatus() == TripStatus.REJECTED, "25 символов");
        error(b::cancel, IllegalStateException.class, "отмена отклонённой");
        BusinessTrip c = make(); c.cancel(); check(c.getStatus() == TripStatus.CANCELLED, "отмена черновика");
        BusinessTrip d = make(); d.submit(); d.cancel(); check(d.getStatus() == TripStatus.CANCELLED, "отмена отправленной");
        BusinessTrip e = make(); e.submit(); e.approve(); e.cancel(); check(e.getStatus() == TripStatus.CANCELLED, "отмена согласованной");
        error(() -> new BusinessTrip("2", employee, LocalDate.of(2026,10,15), LocalDate.of(2026,10,10)), IllegalArgumentException.class, "неверные даты");
        error(() -> new BusinessTrip("2", employee, null, LocalDate.of(2026,10,10)), IllegalArgumentException.class, "нет даты");
        error(() -> new Employee("", "Петров"), IllegalArgumentException.class, "пустой сотрудник");
        BusinessTripService service = new BusinessTripService();
        service.create("55", employee, LocalDate.of(2026,10,10), LocalDate.of(2026,10,11));
        error(() -> service.create("55", employee, LocalDate.of(2026,10,10), LocalDate.of(2026,10,11)), IllegalArgumentException.class, "повторный id");
        check(service.findByStatus(TripStatus.DRAFT).size() == 1, "поиск по статусу");
        System.out.println("Проверки: " + ok + "/" + count);
        if (ok != count) System.exit(1);
    }
}
