import java.time.LocalDate;

public class BusinessTrip {
    private static final int MIN_REASON_LENGTH = 25;
    private String id;
    private Employee employee;
    private LocalDate start;
    private LocalDate end;
    private TripStatus status;
    private String rejectionReason;

    public BusinessTrip(String id, Employee employee, LocalDate start, LocalDate end) {
        if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("Пустой номер заявки");
        if (employee == null) throw new IllegalArgumentException("Нет сотрудника");
        if (start == null || end == null) throw new IllegalArgumentException("Не указана дата");
        if (end.isBefore(start)) throw new IllegalArgumentException("Дата окончания раньше начала");
        this.id = id;
        this.employee = employee;
        this.start = start;
        this.end = end;
        status = TripStatus.DRAFT;
    }
    public String getId() { return id; }
    public Employee getEmployee() { return employee; }
    public LocalDate getStart() { return start; }
    public LocalDate getEnd() { return end; }
    public TripStatus getStatus() { return status; }
    public String getRejectionReason() { return rejectionReason; }

    public void submit() {
        if (status != TripStatus.DRAFT) throw new IllegalStateException("Отправить можно только черновик");
        status = TripStatus.SUBMITTED;
    }
    public void approve() {
        if (status != TripStatus.SUBMITTED) throw new IllegalStateException("Нельзя согласовать заявку");
        status = TripStatus.APPROVED;
    }
    public void reject(String reason) {
        if (status != TripStatus.SUBMITTED) throw new IllegalStateException("Нельзя отклонить заявку");
        if (reason == null || reason.trim().length() < MIN_REASON_LENGTH) {
            throw new IllegalArgumentException("Причина должна быть от 25 символов");
        }
        rejectionReason = reason.trim();
        status = TripStatus.REJECTED;
    }
    public void cancel() {
        if (status != TripStatus.DRAFT && status != TripStatus.SUBMITTED && status != TripStatus.APPROVED) {
            throw new IllegalStateException("Нельзя отменить заявку");
        }
        status = TripStatus.CANCELLED;
    }
    public void complete(LocalDate today) {
        if (status != TripStatus.APPROVED) throw new IllegalStateException("Заявка не согласована");
        if (today == null) throw new IllegalArgumentException("Нет текущей даты");
        if (!today.isAfter(end)) throw new IllegalStateException("Командировка ещё не окончена");
        status = TripStatus.COMPLETED;
    }
}
