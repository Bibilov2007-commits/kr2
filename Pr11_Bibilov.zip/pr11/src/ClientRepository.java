import java.util.*;

public class ClientRepository {
    private final Map<String, Client> clients = new LinkedHashMap<>();
    // Сохранение вызывается после ClientValidator.validate.
    public void save(Client client) {
        if (client == null) throw new IllegalArgumentException("Нет клиента");
        if (clients.containsKey(client.getInn()))
            throw new IllegalArgumentException("Повтор ИНН: " + client.getInn());
        clients.put(client.getInn(), client);
    }
    public Client findByInn(String inn) { return clients.get(inn); }
    public List<Client> findAll() { return new ArrayList<>(clients.values()); }
}
