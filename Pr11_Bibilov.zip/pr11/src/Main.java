import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class Main {
    private static void writeResults(Path directory, ClientRepository repository,
            ClientCsvParser parser, ImportResult result) throws IOException {
        Files.createDirectories(directory);
        try (BufferedWriter writer = Files.newBufferedWriter(directory.resolve("accepted.csv"), StandardCharsets.UTF_8)) {
            writer.write("name;inn;email"); writer.newLine();
            for (Client client : repository.findAll()) { writer.write(parser.toCsv(client)); writer.newLine(); }
        }
        try (BufferedWriter writer = Files.newBufferedWriter(directory.resolve("report.txt"), StandardCharsets.UTF_8)) {
            writer.write("Принято: " + result.getAccepted()); writer.newLine();
            writer.write("Отклонено: " + result.getRejected()); writer.newLine();
            for (ImportError error : result.getErrors()) { writer.write(error.toString()); writer.newLine(); }
        }
    }
    public static void main(String[] args) {
        try {
            Path source = Paths.get(args.length > 0 ? args[0] : "data/sample.csv");
            Path output = Paths.get(args.length > 1 ? args[1] : "output");
            // Не перезаписываем входной файл файлом результата.
            for (String name : new String[] {"accepted.csv", "report.txt"}) {
                Path target = output.resolve(name);
                if (source.toAbsolutePath().normalize().equals(target.toAbsolutePath().normalize())
                        || (Files.exists(source) && Files.exists(target) && Files.isSameFile(source, target)))
                    throw new IllegalArgumentException("Входной файл совпадает с файлом результата");
            }
            ClientCsvParser parser = new ClientCsvParser();
            ClientRepository repository = new ClientRepository();
            ClientImporter importer = new ClientImporter(parser, new ClientValidator(), repository);
            ImportResult result = importer.importFile(source);
            System.out.println("Принято: " + result.getAccepted());
            System.out.println("Отклонено: " + result.getRejected());
            for (ImportError error : result.getErrors()) System.out.println(error);
            writeResults(output, repository, parser, result);
            System.out.println("Результаты записаны в " + output.toAbsolutePath());
        } catch (IOException | IllegalArgumentException ex) {
            System.err.println("Операция завершена с ошибкой: " + ex.getMessage());
            System.exit(1);
        }
    }
}
