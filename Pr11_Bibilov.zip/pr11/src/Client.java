public final class Client {
    private final String name;
    private final String inn;
    private final String email;
    public Client(String name, String inn, String email) {
        this.name = name; this.inn = inn; this.email = email;
    }
    public String getName() { return name; }
    public String getInn() { return inn; }
    public String getEmail() { return email; }
}
