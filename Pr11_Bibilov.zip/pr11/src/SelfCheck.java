import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class SelfCheck {
    private static int passed;
    private static final ClientCsvParser parser = new ClientCsvParser();
    private static final ClientValidator validator = new ClientValidator();
    private static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        System.out.println("PASS " + (++passed) + ": " + name);
    }
    private static void error(String name, Runnable action) {
        try { action.run(); } catch (IllegalArgumentException ex) { check(name, true); return; }
        throw new AssertionError(name + ": expected error");
    }
    private static void valid(String name, String row) { validator.validate(parser.parse(row)); check(name, true); }
    private static ClientImporter importer(ClientRepository repository) {
        return new ClientImporter(parser, validator, repository);
    }
    private static void fileError(String name, Path path, ClientRepository repository) {
        try { importer(repository).importFile(path); }
        catch (IOException ex) { check(name, true); return; }
        throw new AssertionError(name + ": expected IOException");
    }
    public static void main(String[] args) throws IOException {
        valid("10 digit INN", "Анна;0123456789;a@b");
        valid("12 digit INN", "Иван;012345678901;a@b");
        valid("name 25", "А".repeat(25) + ";0123456789;a@b");
        error("name 26", () -> validator.validate(parser.parse("А".repeat(26) + ";0123456789;a@b")));
        error("empty name", () -> validator.validate(parser.parse(" ;0123456789;a@b")));
        for (int size : new int[]{9, 11, 13})
            error("INN length " + size, () -> validator.validate(new Client("A", "1".repeat(size), "a@b")));
        error("INN letters", () -> validator.validate(new Client("A", "123456789x", "a@b")));
        error("INN missing", () -> validator.validate(parser.parse("A;;a@b")));
        error("INN non ASCII digits", () -> validator.validate(new Client("A", "١".repeat(10), "a@b")));
        for (String email : new String[]{"", "abc", "@b", "a@", "a@@b", " @b", "a@ "})
            error("invalid email [" + email + "]", () -> validator.validate(new Client("A", "0123456789", email)));
        error("null email", () -> validator.validate(new Client("A", "0123456789", null)));
        error("missing field", () -> parser.parse("A;0123456789"));
        error("extra field", () -> parser.parse("A;0123456789;a@b;extra"));
        error("empty row", () -> parser.parse(""));
        error("unclosed quote", () -> parser.parse("\"A;0123456789;a@b"));
        error("quote in field", () -> parser.parse("A\"B;0123456789;a@b"));
        error("text after quote", () -> parser.parse("\"A\"x;0123456789;a@b"));
        Client quoted = parser.parse("\"ООО; \"\"А\"\"\";0123456789;a@b");
        check("quoted delimiter and quote", quoted.getName().equals("ООО; \"А\""));
        check("CSV round trip", parser.parse(parser.toCsv(quoted)).getName().equals(quoted.getName()));
        ClientRepository repo = new ClientRepository();
        Client original = parser.parse("Первый;0123456789;first@x"); repo.save(original);
        error("duplicate INN", () -> repo.save(parser.parse("Второй;0123456789;second@x")));
        check("duplicate keeps first", repo.findByInn("0123456789") == original);
        repo.findAll().clear(); check("repository copy", repo.findAll().size() == 1);
        Path dir = Files.createTempDirectory("pr11-check-");
        Path file = dir.resolve("test.csv");
        try {
            String content = "name;inn;email\nАнна;0123456789;a@b\nБрак;bad;a@b\nИван;012345678901;i@b\nПовтор;0123456789;x@y\n\nОлег;2222222222;o@b\n";
            Files.writeString(file, content, StandardCharsets.UTF_8);
            ClientRepository imported = new ClientRepository();
            ImportResult result = importer(imported).importFile(file);
            check("batch accepted", result.getAccepted() == 3);
            check("batch rejected", result.getRejected() == 3);
            check("correct line numbers", result.getErrors().get(0).getLineNumber() == 3
                && result.getErrors().get(1).getLineNumber() == 5 && result.getErrors().get(2).getLineNumber() == 6);
            check("continues after error", imported.findByInn("2222222222") != null);
            check("header excluded", result.getAccepted() + result.getRejected() == 6);
            result.getErrors().clear(); check("errors copy", result.getRejected() == 3);
            ImportResult repeat = importer(imported).importFile(file);
            check("repeat import rejects existing", repeat.getAccepted() == 0 && repeat.getRejected() == 6);
            Files.writeString(file, "name;inn;email\n", StandardCharsets.UTF_8);
            ImportResult empty = importer(new ClientRepository()).importFile(file);
            check("header only", empty.getAccepted() == 0 && empty.getRejected() == 0);
            Files.writeString(file, "", StandardCharsets.UTF_8);
            fileError("empty file", file, repo);
            Files.writeString(file, "wrong;header;line\nA;1234567890;a@b\n", StandardCharsets.UTF_8);
            fileError("bad header", file, repo);
            check("bad header does not save", repo.findAll().size() == 1);
            fileError("missing file", dir.resolve("missing.csv"), repo);
            check("missing file does not save", repo.findAll().size() == 1);
            Files.writeString(file, "\uFEFFname;inn;email\r\nАнна;0123456789;a@b\r\n", StandardCharsets.UTF_8);
            check("BOM and CRLF", importer(new ClientRepository()).importFile(file).getAccepted() == 1);
            Files.write(file, new byte[]{(byte)0xC3, (byte)0x28});
            fileError("invalid UTF8", file, new ClientRepository());
        } finally { Files.deleteIfExists(file); Files.deleteIfExists(dir); }
        System.out.println("TOTAL: " + passed + " passed");
    }
}
