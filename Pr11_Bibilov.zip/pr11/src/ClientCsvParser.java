import java.util.*;

public class ClientCsvParser {
    // Одна запись занимает одну строку. Кавычки и удвоенные кавычки поддерживаются.
    private List<String> fields(String line) {
        if (line == null) throw new IllegalArgumentException("Нет строки");
        List<String> result = new ArrayList<>();
        StringBuilder value = new StringBuilder();
        boolean quoted = false;
        boolean closed = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (quoted) {
                if (ch == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        value.append('"'); i++;
                    } else { quoted = false; closed = true; }
                } else value.append(ch);
            } else if (ch == ';') {
                result.add(value.toString().trim()); value.setLength(0); closed = false;
            } else if (closed) {
                if (!Character.isWhitespace(ch)) throw new IllegalArgumentException("Лишний символ после кавычек");
            } else if (ch == '"') {
                if (!value.toString().trim().isEmpty()) throw new IllegalArgumentException("Кавычка внутри поля");
                value.setLength(0); quoted = true;
            } else value.append(ch);
        }
        if (quoted) throw new IllegalArgumentException("Не закрыты кавычки");
        result.add(value.toString().trim());
        if (result.size() != 3) throw new IllegalArgumentException("Ожидаются 3 поля: name;inn;email");
        return result;
    }
    public void checkHeader(String line) {
        if (line == null) throw new IllegalArgumentException("Файл пуст: нет заголовка");
        if (line.startsWith("\uFEFF")) line = line.substring(1);
        List<String> values = fields(line);
        if (!values.get(0).equalsIgnoreCase("name") || !values.get(1).equalsIgnoreCase("inn")
                || !values.get(2).equalsIgnoreCase("email"))
            throw new IllegalArgumentException("Заголовок должен быть name;inn;email");
    }
    public Client parse(String line) {
        List<String> values = fields(line);
        return new Client(values.get(0), values.get(1), values.get(2));
    }
    public String toCsv(Client client) {
        return escape(client.getName()) + ";" + escape(client.getInn()) + ";" + escape(client.getEmail());
    }
    private String escape(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }
}
