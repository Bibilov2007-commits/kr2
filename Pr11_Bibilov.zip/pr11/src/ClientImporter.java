import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class ClientImporter {
    private final ClientCsvParser parser;
    private final ClientValidator validator;
    private final ClientRepository repository;
    public ClientImporter(ClientCsvParser parser, ClientValidator validator, ClientRepository repository) {
        if (parser == null || validator == null || repository == null)
            throw new IllegalArgumentException("Не заданы компоненты импорта");
        this.parser = parser; this.validator = validator; this.repository = repository;
    }
    public ImportResult importFile(Path path) throws IOException {
        if (path == null) throw new IllegalArgumentException("Не указан путь");
        ImportResult result = new ImportResult();
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            try { parser.checkHeader(header); }
            catch (IllegalArgumentException ex) { throw new IOException("Ошибка заголовка: " + ex.getMessage(), ex); }
            String line;
            int lineNumber = 1;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                try {
                    Client client = parser.parse(line);
                    validator.validate(client);
                    repository.save(client);
                    result.addAccepted();
                } catch (IllegalArgumentException ex) {
                    result.addError(lineNumber, ex.getMessage());
                }
            }
        }
        return result;
    }
}
