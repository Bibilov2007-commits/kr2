public class ClientValidator {
    public static final int MAX_NAME_LENGTH = 25;
    public void validate(Client client) {
        if (client == null) throw new IllegalArgumentException("Нет клиента");
        String name = client.getName();
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Имя обязательно");
        if (name.codePointCount(0, name.length()) > MAX_NAME_LENGTH)
            throw new IllegalArgumentException("Имя длиннее " + MAX_NAME_LENGTH + " символов");
        String inn = client.getInn();
        if (inn == null || !inn.matches("[0-9]{10}|[0-9]{12}"))
            throw new IllegalArgumentException("ИНН должен содержать 10 или 12 цифр");
        String email = client.getEmail();
        if (email == null) throw new IllegalArgumentException("Email обязателен");
        int at = email.indexOf('@');
        if (at <= 0 || at != email.lastIndexOf('@') || at == email.length() - 1
                || email.substring(0, at).trim().isEmpty() || email.substring(at + 1).trim().isEmpty())
            throw new IllegalArgumentException("Email должен содержать один @ и непустые части");
    }
}
