import java.util.*;

public class ImportResult {
    private int accepted;
    private final List<ImportError> errors = new ArrayList<>();
    public void addAccepted() { accepted++; }
    public void addError(int lineNumber, String reason) { errors.add(new ImportError(lineNumber, reason)); }
    public int getAccepted() { return accepted; }
    public int getRejected() { return errors.size(); }
    public List<ImportError> getErrors() { return new ArrayList<>(errors); }
}
