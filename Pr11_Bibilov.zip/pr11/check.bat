@echo off
cd /d "%~dp0"
chcp 65001 >nul
if not exist out mkdir out
javac -encoding UTF-8 -d out src\*.java
if errorlevel 1 goto end
java -Dfile.encoding=UTF-8 -cp out SelfCheck
:end
pause
