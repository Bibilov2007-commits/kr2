public class TimesheetAnalyzer {
    private static final int DAYS = 5;
    private static final int MAX_HOURS = 16;
    private static final int DAILY_NORM = 8 + 8 * 25 / 100; // вариант 4: +25%
    private static final int WEEKLY_NORM = 40;

    public int[] parseHours(String text) {
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException("Табель не заполнен");
        }
        String[] parts = text.split(";", -1);
        if (parts.length != DAYS) {
            throw new IllegalArgumentException("Должно быть ровно 5 значений, получено: " + parts.length);
        }
        int[] hours = new int[DAYS];
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i].trim();
            if (part.isEmpty()) {
                throw new IllegalArgumentException("Пустое значение в позиции " + (i + 1));
            }
            try {
                hours[i] = Integer.parseInt(part);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Не число в позиции " + (i + 1) + ": " + part);
            }
            if (hours[i] < 0 || hours[i] > MAX_HOURS) {
                throw new IllegalArgumentException("Часы вне диапазона 0..16 в позиции " + (i + 1));
            }
        }
        return hours;
    }

    public int total(int[] hours) {
        int sum = 0;
        for (int i = 0; i < hours.length; i++) sum += hours[i];
        return sum;
    }

    public double average(int[] hours) { return (double) total(hours) / hours.length; }

    public int overtimeDays(int[] hours) {
        int count = 0;
        for (int hour : hours) if (hour > DAILY_NORM) count++;
        return count;
    }

    public int weeklyOvertime(int[] hours) { return Math.max(0, total(hours) - WEEKLY_NORM); }

    public String report(String text) {
        int[] hours = parseHours(text);
        return String.format(java.util.Locale.US,
            "Всего: %d ч; среднее: %.1f ч; дней с переработкой: %d; недельная переработка: %d ч",
            total(hours), average(hours), overtimeDays(hours), weeklyOvertime(hours));
    }
}
