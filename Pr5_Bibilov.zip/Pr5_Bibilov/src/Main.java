import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите часы за 5 дней через ;");
        String line = scanner.hasNextLine() ? scanner.nextLine() : "";
        try {
            System.out.println(new TimesheetAnalyzer().report(line));
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }
}
