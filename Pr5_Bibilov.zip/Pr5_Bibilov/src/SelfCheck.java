public class SelfCheck {
    private static int passed = 0;
    private static final TimesheetAnalyzer a = new TimesheetAnalyzer();

    private static void ok(String text, int total, int days, int weekly) {
        int[] h = a.parseHours(text);
        if (a.total(h) != total || a.overtimeDays(h) != days || a.weeklyOvertime(h) != weekly)
            throw new AssertionError("Не прошел тест: " + text);
        passed++;
        System.out.println("OK: " + text);
    }
    private static void error(String text, String expected) {
        try {
            a.parseHours(text);
            throw new AssertionError("Ожидалась ошибка: " + text);
        } catch (IllegalArgumentException e) {
            if (!e.getMessage().contains(expected)) throw new AssertionError(e.getMessage());
            passed++;
            System.out.println("OK: ошибка для " + text);
        }
    }
    public static void main(String[] args) {
        ok("8;8;8;8;8", 40, 0, 0);
        ok("0;0;0;0;0", 0, 0, 0);
        ok("16;16;16;16;16", 80, 5, 40);
        ok("10;11;10;8;8", 47, 1, 7);
        ok("8;8;8;8;8", 40, 0, 0);
        error("", "не заполнен");
        error("8;8;8;8", "ровно 5");
        error("8;8;17;8;8", "позиции 3");
        error("8;abc;8;8;8", "позиции 2");
        error("8;;8;8;8", "позиции 2");
        error("8;-1;8;8;8", "позиции 2");
        System.out.println("Проверок пройдено: " + passed);
    }
}
