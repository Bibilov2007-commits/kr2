Практическая работа №5. Бибилов Марат Робертович. Группа ЭФБО-08-25. Зачётка 25Т0751.
Запуск из папки проекта:
javac -encoding UTF-8 -d out src/*.java
java -cp out Main
java -cp out SelfCheck
