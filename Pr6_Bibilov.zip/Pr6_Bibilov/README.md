# Практическая работа №6
Бибилов Марат Робертович, ЭФБО-08-25, 25Т0751, вариант 4.

Компиляция из папки проекта: `javac -encoding UTF-8 -d out src/*.java`

Проверка: `java -cp out SelfCheck`

Запуск: `java -cp out Main`
