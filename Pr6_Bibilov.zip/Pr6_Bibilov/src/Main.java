import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ApprovalRouter router = new ApprovalRouter();
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Сумма заявки: ");
            long amount = Long.parseLong(scanner.nextLine().trim());
            System.out.print("Срочная (true/false): ");
            boolean urgent = readBoolean(scanner.nextLine());
            System.out.print("Риск (LOW/MEDIUM/HIGH): ");
            RiskLevel risk = RiskLevel.valueOf(scanner.nextLine().trim().toUpperCase());
            System.out.print("Есть персональные данные (true/false): ");
            boolean personal = readBoolean(scanner.nextLine());
            System.out.println("Маршрут: " + router.route(amount, urgent, risk, personal));
        } catch (IllegalArgumentException error) {
            System.out.println("Ошибка: " + error.getMessage());
        }
    }

    private static boolean readBoolean(String text) {
        String value = text.trim().toLowerCase();
        if (value.equals("true")) return true;
        if (value.equals("false")) return false;
        throw new IllegalArgumentException("Введите true или false");
    }
}
