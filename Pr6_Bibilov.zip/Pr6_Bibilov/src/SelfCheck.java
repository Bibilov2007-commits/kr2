public class SelfCheck {
    private static int checked = 0;
    private static final ApprovalRouter router = new ApprovalRouter();

    private static void check(long amount, boolean urgent, RiskLevel risk,
                              boolean personal, ApprovalRoute expected) {
        ApprovalRoute actual = router.route(amount, urgent, risk, personal);
        if (actual != expected) {
            throw new AssertionError("Ожидалось " + expected + ", получено " + actual);
        }
        checked++;
    }

    private static void invalid(long amount, RiskLevel risk) {
        try {
            router.route(amount, false, risk, false);
            throw new AssertionError("Ожидалась ошибка входных данных");
        } catch (IllegalArgumentException expected) {
            checked++;
        }
    }

    public static void main(String[] args) {
        check(0, false, RiskLevel.LOW, false, ApprovalRoute.STANDARD);
        check(499999, true, RiskLevel.LOW, false, ApprovalRoute.FAST_TRACK);
        check(500000, false, RiskLevel.MEDIUM, false, ApprovalRoute.STANDARD);
        check(500001, true, RiskLevel.LOW, false, ApprovalRoute.FAST_TRACK);
        check(500024, false, RiskLevel.LOW, false, ApprovalRoute.STANDARD);
        check(500025, false, RiskLevel.LOW, false, ApprovalRoute.FINANCE_REVIEW);
        check(500026, true, RiskLevel.MEDIUM, false, ApprovalRoute.FINANCE_REVIEW);
        check(10, true, RiskLevel.HIGH, false, ApprovalRoute.DIRECTOR_REVIEW);
        check(900000, true, RiskLevel.HIGH, true, ApprovalRoute.SECURITY_REVIEW);
        check(1, false, RiskLevel.LOW, true, ApprovalRoute.SECURITY_REVIEW);
        check(1, false, RiskLevel.HIGH, false, ApprovalRoute.DIRECTOR_REVIEW);
        check(1, true, RiskLevel.MEDIUM, false, ApprovalRoute.FAST_TRACK);
        invalid(-1, RiskLevel.LOW);
        invalid(5, null);
        System.out.println("Все проверки пройдены: " + checked);
    }
}
