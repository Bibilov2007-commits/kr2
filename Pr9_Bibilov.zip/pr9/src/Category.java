public enum Category { COMPUTER, MONITOR, PRINTER, OTHER }
