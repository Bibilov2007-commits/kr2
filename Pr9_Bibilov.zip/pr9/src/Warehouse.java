import java.util.*;

public class Warehouse {
    public static final int MIN_RESERVE = 25;
    private final Map<String, StockItem> items = new LinkedHashMap<>();
    private final List<Operation> operations = new ArrayList<>();

    private String cleanCode(String code) {
        if (code == null || code.trim().isEmpty()) throw new IllegalArgumentException("Empty code");
        return code.trim();
    }
    private void checkAmount(int amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
    }
    public void addItem(String code, String name, Category category) {
        StockItem item = new StockItem(code, name, category, 0);
        if (items.containsKey(item.getCode())) throw new IllegalArgumentException("Duplicate code");
        items.put(item.getCode(), item);
    }
    public StockItem findByCode(String code) {
        StockItem item = items.get(cleanCode(code));
        if (item == null) throw new IllegalArgumentException("Unknown code");
        return item;
    }
    public void receive(String code, int amount) {
        checkAmount(amount);
        StockItem item = findByCode(code);
        if (amount > Integer.MAX_VALUE - item.getQuantity())
            throw new IllegalArgumentException("Quantity overflow");
        int balance = item.getQuantity() + amount;
        items.put(item.getCode(), item.withQuantity(balance));
        operations.add(new Operation(Operation.Type.RECEIVE, item.getCode(), amount, balance));
    }
    public void issue(String code, int amount) {
        checkAmount(amount);
        StockItem item = findByCode(code);
        int balance = item.getQuantity() - amount;
        if (balance < MIN_RESERVE) throw new IllegalArgumentException("Reserve must be at least " + MIN_RESERVE);
        items.put(item.getCode(), item.withQuantity(balance));
        operations.add(new Operation(Operation.Type.ISSUE, item.getCode(), amount, balance));
    }
    public List<StockItem> findByCategory(Category category) {
        if (category == null) throw new IllegalArgumentException("Empty category");
        List<StockItem> result = new ArrayList<>();
        for (StockItem item : items.values())
            if (item.getCategory() == category) result.add(item);
        return result;
    }
    public Map<Category, Long> totalsByCategory() {
        Map<Category, Long> result = new EnumMap<>(Category.class);
        for (StockItem item : items.values()) {
            Category category = item.getCategory();
            result.put(category, result.getOrDefault(category, 0L) + item.getQuantity());
        }
        return result;
    }
    public Set<Category> getCategories() {
        Set<Category> result = new HashSet<>();
        for (StockItem item : items.values()) result.add(item.getCategory());
        return result;
    }
    public List<StockItem> getItems() { return new ArrayList<>(items.values()); }
    public List<Operation> getOperations() { return new ArrayList<>(operations); }
}
