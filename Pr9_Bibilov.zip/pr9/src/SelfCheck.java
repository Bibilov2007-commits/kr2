import java.util.*;

public class SelfCheck {
    private static int passed;
    private static void check(String name, boolean condition) {
        if (!condition) throw new AssertionError(name);
        System.out.println("PASS " + (++passed) + ": " + name);
    }
    private static void error(String name, Runnable action) {
        try { action.run(); } catch (IllegalArgumentException ex) { check(name, true); return; }
        throw new AssertionError(name + ": error expected");
    }
    public static void main(String[] args) {
        Warehouse w = new Warehouse();
        w.addItem("PC1", "Computer", Category.COMPUTER);
        w.receive("PC1", 30);
        check("receive 30", w.findByCode("PC1").getQuantity() == 30);
        w.issue("PC1", 5);
        check("exact reserve 25", w.findByCode("PC1").getQuantity() == 25);
        error("reserve 24 rejected", () -> w.issue("PC1", 1));
        check("failed issue changes nothing", w.getOperations().size() == 2 && w.findByCode("PC1").getQuantity() == 25);
        error("zero receive", () -> w.receive("PC1", 0));
        error("negative issue", () -> w.issue("PC1", -1));
        error("zero issue", () -> w.issue("PC1", 0));
        error("negative receive", () -> w.receive("PC1", -1));
        error("empty code", () -> w.addItem(" ", "X", Category.OTHER));
        error("null code", () -> w.findByCode(null));
        error("empty name", () -> w.addItem("X", "", Category.OTHER));
        error("null category", () -> w.addItem("X", "X", null));
        error("duplicate code", () -> w.addItem(" PC1 ", "X", Category.OTHER));
        error("unknown code", () -> w.issue("NONE", 1));
        error("issue more than stock", () -> w.issue("PC1", 26));
        w.findByCategory(Category.COMPUTER).clear();
        check("search list independent", w.findByCategory(Category.COMPUTER).size() == 1);
        w.getItems().clear(); w.getOperations().clear(); w.getCategories().clear(); w.totalsByCategory().clear();
        check("all collections independent", w.getItems().size() == 1 && w.getOperations().size() == 2 && w.getCategories().size() == 1 && w.totalsByCategory().get(Category.COMPUTER) == 25L);
        StockItem snapshot = w.findByCode("PC1");
        w.receive("PC1", 1);
        check("item snapshot unchanged", snapshot.getQuantity() == 25 && w.findByCode("PC1").getQuantity() == 26);
        w.addItem("PC2", "Computer 2", Category.COMPUTER); w.receive("PC2", 10);
        check("category total", w.totalsByCategory().get(Category.COMPUTER) == 36L);
        check("unique categories", w.getCategories().size() == 1);
        StockItem a = new StockItem("K", "A", Category.OTHER, 0);
        StockItem b = new StockItem("K", "B", Category.PRINTER, 1);
        Set<StockItem> set = new HashSet<>(); set.add(a); set.add(b);
        check("equals and hashCode by code", a.equals(b) && a.hashCode() == b.hashCode() && set.size() == 1);
        w.addItem("MAX", "Max", Category.OTHER); w.receive("MAX", Integer.MAX_VALUE);
        check("max int accepted", w.findByCode("MAX").getQuantity() == Integer.MAX_VALUE);
        int before = w.getOperations().size();
        error("overflow rejected", () -> w.receive("MAX", 1));
        check("overflow leaves state intact", w.findByCode("MAX").getQuantity() == Integer.MAX_VALUE && w.getOperations().size() == before);
        w.addItem("MAX2", "Max2", Category.OTHER); w.receive("MAX2", Integer.MAX_VALUE);
        check("long total", w.totalsByCategory().get(Category.OTHER) == 4294967294L);
        CsvLoader loader = new CsvLoader();
        error("bad number", () -> loader.execute("RECEIVE;PC1;;;abc", w));
        error("missing number", () -> loader.execute("RECEIVE;PC1;;;", w));
        error("bad category", () -> loader.execute("ADD;X;Name;INVALID;", w));
        error("bad field count", () -> loader.execute("ADD;X", w));
        error("unknown command", () -> loader.execute("DELETE;PC1;;;1", w));
        error("null search category", () -> w.findByCategory(null));
        check("empty search", w.findByCategory(Category.PRINTER).isEmpty());
        System.out.println("TOTAL: " + passed + " passed");
    }
}
