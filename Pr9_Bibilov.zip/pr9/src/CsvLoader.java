import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class CsvLoader {
    // Формат: команда;код;название;категория;количество
    public void load(Path path, Warehouse warehouse, PrintStream out) throws IOException {
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            try {
                execute(line, warehouse);
                out.println("OK line " + (i + 1));
            } catch (IllegalArgumentException ex) {
                out.println("ERROR line " + (i + 1) + ": " + ex.getMessage());
            }
        }
    }
    public void execute(String line, Warehouse warehouse) {
        if (line == null) throw new IllegalArgumentException("Empty line");
        String[] parts = line.split(";", -1);
        if (parts.length != 5) throw new IllegalArgumentException("Expected 5 fields");
        for (int i = 0; i < parts.length; i++) parts[i] = parts[i].trim();
        switch (parts[0]) {
            case "ADD":
                if (!parts[4].isEmpty()) throw new IllegalArgumentException("ADD quantity must be empty");
                warehouse.addItem(parts[1], parts[2], Category.valueOf(parts[3]));
                break;
            case "RECEIVE":
            case "ISSUE":
                if (!parts[2].isEmpty() || !parts[3].isEmpty())
                    throw new IllegalArgumentException("Name and category must be empty");
                int amount = Integer.parseInt(parts[4]);
                if (parts[0].equals("RECEIVE")) warehouse.receive(parts[1], amount);
                else warehouse.issue(parts[1], amount);
                break;
            default: throw new IllegalArgumentException("Unknown command");
        }
    }
}
