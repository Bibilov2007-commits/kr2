import java.io.IOException;
import java.nio.file.*;

public class Main {
    public static void main(String[] args) {
        Warehouse warehouse = new Warehouse();
        Path file = Paths.get(args.length == 0 ? "data/sample.csv" : args[0]);
        try {
            new CsvLoader().load(file, warehouse, System.out);
        } catch (IOException ex) {
            System.err.println("Cannot read file: " + file);
            System.exit(1);
        }
        System.out.println("ITEMS");
        for (StockItem item : warehouse.getItems()) System.out.println(item);
        System.out.println("COMPUTERS: " + warehouse.findByCategory(Category.COMPUTER));
        System.out.println("TOTALS: " + warehouse.totalsByCategory());
        System.out.println("CATEGORIES: " + warehouse.getCategories());
        System.out.println("OPERATIONS");
        for (Operation operation : warehouse.getOperations()) System.out.println(operation);
    }
}
