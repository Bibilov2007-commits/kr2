public final class Operation {
    public enum Type { RECEIVE, ISSUE }
    private final Type type;
    private final String code;
    private final int amount;
    private final int balance;
    public Operation(Type type, String code, int amount, int balance) {
        this.type = type; this.code = code; this.amount = amount; this.balance = balance;
    }
    public Type getType() { return type; }
    public String getCode() { return code; }
    public int getAmount() { return amount; }
    public int getBalance() { return balance; }
    @Override public String toString() { return type + " | " + code + " | " + amount + " | balance=" + balance; }
}
