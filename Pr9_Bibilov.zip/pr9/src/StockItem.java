public final class StockItem {
    private final String code;
    private final String name;
    private final Category category;
    private final int quantity;

    public StockItem(String code, String name, Category category, int quantity) {
        if (code == null || code.trim().isEmpty()) throw new IllegalArgumentException("Empty code");
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Empty name");
        if (category == null) throw new IllegalArgumentException("Empty category");
        if (quantity < 0) throw new IllegalArgumentException("Negative quantity");
        this.code = code.trim(); this.name = name.trim();
        this.category = category; this.quantity = quantity;
    }
    public String getCode() { return code; }
    public String getName() { return name; }
    public Category getCategory() { return category; }
    public int getQuantity() { return quantity; }
    public StockItem withQuantity(int value) { return new StockItem(code, name, category, value); }
    @Override public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof StockItem)) return false;
        return code.equals(((StockItem) obj).code);
    }
    @Override public int hashCode() { return code.hashCode(); }
    @Override public String toString() { return code + " | " + name + " | " + category + " | " + quantity; }
}
