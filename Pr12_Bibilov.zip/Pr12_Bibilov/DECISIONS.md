# Практическая работа №12
Бибилов Марат Робертович, ЭФБО-08-25, зачётка 25Т0751.
Вариант: 51 % 8 + 1 = 4.

1. Порог крупных продаж равен 25, значение 25 включается. Он хранится в константе LARGE_SALE_THRESHOLD класса SalesAnalyticsService, чтобы менять правило в одном месте.
2. В потоках нет изменения внешних списков. Для результатов применяются collect, groupingBy, а при поиске максимума — Optional.

Исправление ошибки: `sales.stream().filter(this::isLarge).collect(Collectors.toList())` вместо `forEach(result::add)`.

Запуск (из папки проекта):
```
javac -encoding UTF-8 -d out src/*.java
java -cp out Main data/sample.csv
```
Формат CSV: `id,manager,region,amount`; идентификаторы не повторяются.
