import java.util.*;
import java.util.stream.Collectors;

public class SalesAnalyticsService {
    // Вариант 4: порог крупной продажи 25 (включительно).
    public static final double LARGE_SALE_THRESHOLD = 25.0;

    private boolean isLarge(Sale sale) {
        return sale.getAmount() >= LARGE_SALE_THRESHOLD;
    }

    public List<Sale> topSales(List<Sale> sales, int limit) {
        Objects.requireNonNull(sales, "Список продаж отсутствует");
        if (limit < 0) throw new IllegalArgumentException("Лимит меньше нуля");
        return sales.stream()
                .filter(this::isLarge)
                .sorted(Comparator.comparingDouble(Sale::getAmount).reversed()
                        .thenComparing(Sale::getId))
                .limit(limit)
                .collect(Collectors.toList());
    }

    public Optional<Sale> maxSale(List<Sale> sales) {
        Objects.requireNonNull(sales, "Список продаж отсутствует");
        return sales.stream().max(Comparator.comparingDouble(Sale::getAmount));
    }

    public Map<String, Double> totalsByManager(List<Sale> sales) {
        Objects.requireNonNull(sales, "Список продаж отсутствует");
        return sales.stream().collect(Collectors.groupingBy(Sale::getManager,
                TreeMap::new, Collectors.summingDouble(Sale::getAmount)));
    }

    public double averageByRegion(List<Sale> sales, String region) {
        Objects.requireNonNull(sales, "Список продаж отсутствует");
        if (region == null || region.trim().isEmpty())
            throw new IllegalArgumentException("Регион не указан");
        return sales.stream().filter(s -> s.getRegion().equalsIgnoreCase(region.trim()))
                .mapToDouble(Sale::getAmount).average().orElse(0.0);
    }
}
