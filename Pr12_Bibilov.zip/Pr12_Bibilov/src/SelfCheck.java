import java.util.*;

public class SelfCheck {
    private static void test(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
        System.out.println("OK: " + description);
    }

    public static void run() {
        SalesAnalyticsService service = new SalesAnalyticsService();
        List<Sale> sales = Arrays.asList(
                new Sale("1", "Иван", "Москва", 24.99),
                new Sale("2", "Иван", "Москва", 25),
                new Sale("3", "Анна", "Казань", 40),
                new Sale("4", "Анна", "Москва", 40));
        test(service.topSales(sales, 10).size() == 3, "Граница 24.99 исключена, 25 включена");
        test(service.topSales(sales, 2).get(0).getId().equals("3"), "Сортировка по сумме и ID");
        test(!service.maxSale(Collections.emptyList()).isPresent(), "Пустой список -> Optional.empty");
        test(Math.abs(service.totalsByManager(sales).get("Иван") - 49.99) < 0.00001, "Сумма по менеджеру");
        test(service.averageByRegion(sales, "Нет") == 0, "Неизвестный регион -> 0");
        test(service.topSales(sales, 0).isEmpty(), "Лимит 0 -> пусто");
        test(sales.size() == 4, "Исходный список не изменён");
        boolean bad = false;
        try { new Sale("5", "Иван", "Москва", -1); } catch (IllegalArgumentException e) { bad = true; }
        test(bad, "Отрицательная сумма -> ошибка");
        bad = false;
        try { service.topSales(sales, -1); } catch (IllegalArgumentException e) { bad = true; }
        test(bad, "Отрицательный лимит -> ошибка");
    }
}
