import java.nio.file.Paths;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        String file = args.length > 0 ? args[0] : "data/sample.csv";
        List<Sale> sales = new SalesCsvReader().read(Paths.get(file));
        SalesAnalyticsService service = new SalesAnalyticsService();
        System.out.println("Топ-3 крупных продаж:");
        service.topSales(sales, 3).forEach(System.out::println);
        System.out.println("Максимальная: " + service.maxSale(sales).map(Object::toString).orElse("нет продаж"));
        System.out.println("Итого по менеджерам: " + service.totalsByManager(sales));
        System.out.println("Средняя сумма по Москве: " + service.averageByRegion(sales, "Москва"));
        SelfCheck.run();
    }
}
