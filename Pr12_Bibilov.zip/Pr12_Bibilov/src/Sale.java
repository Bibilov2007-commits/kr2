public class Sale {
    private final String id;
    private final String manager;
    private final String region;
    private final double amount;

    public Sale(String id, String manager, String region, double amount) {
        if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("Пустой ID");
        if (manager == null || manager.trim().isEmpty()) throw new IllegalArgumentException("Пустой менеджер");
        if (region == null || region.trim().isEmpty()) throw new IllegalArgumentException("Пустой регион");
        if (!Double.isFinite(amount) || amount < 0) throw new IllegalArgumentException("Неверная сумма");
        this.id = id.trim();
        this.manager = manager.trim();
        this.region = region.trim();
        this.amount = amount;
    }

    public String getId() { return id; }
    public String getManager() { return manager; }
    public String getRegion() { return region; }
    public double getAmount() { return amount; }

    @Override
    public String toString() {
        return id + " | " + manager + " | " + region + " | " + amount;
    }
}
