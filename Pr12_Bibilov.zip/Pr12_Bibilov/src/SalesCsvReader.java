import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class SalesCsvReader {
    public List<Sale> read(Path path) throws IOException {
        List<Sale> result = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        int lineNumber = 0;
        for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
            lineNumber++;
            if (line.trim().isEmpty()) continue;
            String[] p = line.split(",", -1);
            if (lineNumber == 1 && p.length == 4 && p[0].trim().equalsIgnoreCase("id")) continue;
            if (p.length != 4) throw new IllegalArgumentException("Строка " + lineNumber + ": нужно 4 поля");
            try {
                double value = Double.parseDouble(p[3].trim());
                Sale sale = new Sale(p[0], p[1], p[2], value);
                if (!ids.add(sale.getId()))
                    throw new IllegalArgumentException("Повтор ID " + sale.getId());
                result.add(sale);
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Строка " + lineNumber + ": " + e.getMessage(), e);
            }
        }
        return Collections.unmodifiableList(result);
    }
}
