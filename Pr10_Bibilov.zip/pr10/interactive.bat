@echo off
call "%~dp0run.bat" --interactive
