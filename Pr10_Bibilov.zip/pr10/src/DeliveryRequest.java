public final class DeliveryRequest {
    private final DeliveryType type;
    private final double weight;
    private final double distance;
    public DeliveryRequest(DeliveryType type, double weight, double distance) {
        if (type == null) throw new IllegalArgumentException("Не указан способ доставки");
        if (!Double.isFinite(weight) || weight <= 0)
            throw new IllegalArgumentException("Вес должен быть конечным числом больше нуля");
        if (!Double.isFinite(distance) || distance < 0)
            throw new IllegalArgumentException("Расстояние должно быть конечным числом не меньше нуля");
        this.type = type; this.weight = weight; this.distance = distance;
    }
    public DeliveryType getType() { return type; }
    public double getWeight() { return weight; }
    public double getDistance() { return distance; }
}
