public class DistancePolicy implements DeliveryPolicy {
    public static final double MAX_WEIGHT = 20;
    public static final double MAX_DISTANCE = 100;
    public static final double PRICE_PER_KM = 25;
    @Override public boolean supports(DeliveryRequest request) {
        return request != null && request.getWeight() <= MAX_WEIGHT
            && request.getDistance() <= MAX_DISTANCE;
    }
    @Override public double calculateCost(DeliveryRequest request) {
        if (!supports(request)) throw new IllegalArgumentException("По километрам: вес не больше 20 кг, расстояние не больше 100 км");
        return PRICE_PER_KM * request.getDistance();
    }
}
