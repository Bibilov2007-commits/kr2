public class PickupPolicy implements DeliveryPolicy {
    public static final double MAX_WEIGHT = 100;
    public static final double MAX_DISTANCE = 0;
    @Override public boolean supports(DeliveryRequest request) {
        return request != null && request.getWeight() <= MAX_WEIGHT
            && request.getDistance() <= MAX_DISTANCE;
    }
    @Override public double calculateCost(DeliveryRequest request) {
        if (!supports(request)) throw new IllegalArgumentException("Самовывоз: вес не больше 100 кг, расстояние равно 0");
        return 0.0;
    }
}
