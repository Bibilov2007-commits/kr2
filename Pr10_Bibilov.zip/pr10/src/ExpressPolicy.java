public class ExpressPolicy implements DeliveryPolicy {
    public static final double MAX_WEIGHT = 10;
    public static final double MAX_DISTANCE = 50;
    public static final double BASE_COST = 400;
    public static final double PRICE_PER_KM = 30;
    @Override public boolean supports(DeliveryRequest request) {
        return request != null && request.getWeight() <= MAX_WEIGHT
            && request.getDistance() <= MAX_DISTANCE;
    }
    @Override public double calculateCost(DeliveryRequest request) {
        if (!supports(request)) throw new IllegalArgumentException("Экспресс: вес не больше 10 кг, расстояние не больше 50 км");
        return BASE_COST + PRICE_PER_KM * request.getDistance();
    }
}
