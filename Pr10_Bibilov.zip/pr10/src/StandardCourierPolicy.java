public class StandardCourierPolicy implements DeliveryPolicy {
    public static final double MAX_WEIGHT = 30;
    public static final double MAX_DISTANCE = 500;
    public static final double BASE_COST = 200;
    public static final double PRICE_PER_KM = 15;
    @Override public boolean supports(DeliveryRequest request) {
        return request != null && request.getWeight() <= MAX_WEIGHT
            && request.getDistance() <= MAX_DISTANCE;
    }
    @Override public double calculateCost(DeliveryRequest request) {
        if (!supports(request)) throw new IllegalArgumentException("Курьер: вес не больше 30 кг, расстояние не больше 500 км");
        return BASE_COST + PRICE_PER_KM * request.getDistance();
    }
}
