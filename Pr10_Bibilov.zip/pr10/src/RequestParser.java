import java.util.Locale;

public class RequestParser {
    public DeliveryRequest parse(String line) {
        if (line == null || line.trim().isEmpty()) throw new IllegalArgumentException("Пустая строка");
        String[] fields = line.split(";", -1);
        if (fields.length != 3) throw new IllegalArgumentException("Нужны поля: способ;вес;расстояние");
        DeliveryType type;
        try {
            type = DeliveryType.valueOf(fields[0].trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Неизвестный способ: " + fields[0]);
        }
        double weight, distance;
        try {
            weight = Double.parseDouble(fields[1].trim());
            distance = Double.parseDouble(fields[2].trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Вес и расстояние должны быть числами");
        }
        return new DeliveryRequest(type, weight, distance);
    }
}
