public class SelfCheck {
    private static int passed = 0;
    private static final DeliveryService service = new DeliveryService(new DeliveryPolicyFactory());
    private static void check(String name, boolean result) {
        if (!result) throw new AssertionError(name);
        System.out.println("PASS " + (++passed) + ": " + name);
    }
    private static void error(String name, Runnable action) {
        try { action.run(); } catch (IllegalArgumentException ex) { check(name, true); return; }
        throw new AssertionError(name + ": expected error");
    }
    private static double cost(DeliveryType type, double weight, double distance) {
        return service.calculate(new DeliveryRequest(type, weight, distance));
    }
    public static void main(String[] args) {
        check("pickup", cost(DeliveryType.PICKUP, 5, 0) == 0);
        check("standard", cost(DeliveryType.STANDARD, 5, 10) == 350);
        check("express", cost(DeliveryType.EXPRESS, 5, 10) == 700);
        check("variant 4", cost(DeliveryType.DISTANCE, 5, 10) == 250);
        check("zero distance", cost(DeliveryType.DISTANCE, 5, 0) == 0);
        check("small positive weight", cost(DeliveryType.STANDARD, 0.01, 0) == 200);
        check("pickup upper weight", cost(DeliveryType.PICKUP, 100, 0) == 0);
        error("pickup weight too high", () -> cost(DeliveryType.PICKUP, 100.01, 0));
        error("pickup distance not zero", () -> cost(DeliveryType.PICKUP, 1, 0.01));
        check("standard upper bounds", cost(DeliveryType.STANDARD, 30, 500) == 7700);
        error("standard weight too high", () -> cost(DeliveryType.STANDARD, 30.01, 10));
        error("standard distance too high", () -> cost(DeliveryType.STANDARD, 1, 500.01));
        check("express upper bounds", cost(DeliveryType.EXPRESS, 10, 50) == 1900);
        error("express weight too high", () -> cost(DeliveryType.EXPRESS, 10.01, 1));
        error("express distance too high", () -> cost(DeliveryType.EXPRESS, 1, 50.01));
        check("individual upper bounds", cost(DeliveryType.DISTANCE, 20, 100) == 2500);
        error("individual weight too high", () -> cost(DeliveryType.DISTANCE, 20.01, 1));
        error("individual distance too high", () -> cost(DeliveryType.DISTANCE, 1, 100.01));
        error("zero weight", () -> cost(DeliveryType.STANDARD, 0, 1));
        error("negative weight", () -> cost(DeliveryType.STANDARD, -1, 1));
        error("negative distance", () -> cost(DeliveryType.STANDARD, 1, -1));
        error("NaN weight", () -> cost(DeliveryType.STANDARD, Double.NaN, 1));
        error("infinite distance", () -> cost(DeliveryType.STANDARD, 1, Double.POSITIVE_INFINITY));
        error("null type", () -> cost(null, 1, 1));
        error("null request", () -> service.calculate(null));
        error("null factory", () -> new DeliveryService(null));
        RequestParser parser = new RequestParser();
        error("empty input", () -> parser.parse(""));
        error("missing value", () -> parser.parse("STANDARD;;10"));
        error("bad number", () -> parser.parse("STANDARD;abc;10"));
        error("unknown type", () -> parser.parse("DRONE;1;10"));
        error("conflicting type", () -> parser.parse("STANDARD/EXPRESS;1;10"));
        error("extra field", () -> parser.parse("STANDARD;1;10;20"));
        error("NaN in input", () -> parser.parse("STANDARD;1;NaN"));
        check("spaces and lower case", service.calculate(parser.parse(" standard ; 5 ; 10 ")) == 350);
        check("repeated request", service.calculate(parser.parse("STANDARD;5;10")) == 350);
        check("round to kopecks", cost(DeliveryType.DISTANCE, 1, 1.234) == 30.85);
        DeliveryPolicy policy = new ExpressPolicy();
        check("polymorphic call", policy.calculateCost(new DeliveryRequest(DeliveryType.EXPRESS, 2, 3)) == 490);
        error("direct policy invalid request", () -> policy.calculateCost(new DeliveryRequest(DeliveryType.EXPRESS, 11, 3)));
        check("null unsupported", !policy.supports(null));
        System.out.println("TOTAL: " + passed + " passed");
    }
}
