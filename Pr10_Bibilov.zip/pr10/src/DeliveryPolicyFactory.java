public class DeliveryPolicyFactory {
    public DeliveryPolicy get(DeliveryType type) {
        if (type == null) throw new IllegalArgumentException("Не указан способ доставки");
        switch (type) {
            case PICKUP: return new PickupPolicy();
            case STANDARD: return new StandardCourierPolicy();
            case EXPRESS: return new ExpressPolicy();
            case DISTANCE: return new DistancePolicy();
            default: throw new IllegalArgumentException("Неизвестный способ доставки");
        }
    }
}
