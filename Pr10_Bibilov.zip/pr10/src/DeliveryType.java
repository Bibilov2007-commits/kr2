public enum DeliveryType { PICKUP, STANDARD, EXPRESS, DISTANCE }
