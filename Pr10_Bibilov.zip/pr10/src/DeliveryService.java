import java.math.BigDecimal;
import java.math.RoundingMode;

public class DeliveryService {
    private final DeliveryPolicyFactory factory;
    public DeliveryService(DeliveryPolicyFactory factory) {
        if (factory == null) throw new IllegalArgumentException("Не указана фабрика");
        this.factory = factory;
    }
    public double calculate(DeliveryRequest request) {
        if (request == null) throw new IllegalArgumentException("Не указан заказ");
        DeliveryPolicy policy = factory.get(request.getType());
        if (!policy.supports(request))
            throw new IllegalArgumentException("Доставка " + request.getType()
                + " невозможна при весе " + request.getWeight()
                + " кг и расстоянии " + request.getDistance() + " км");
        double cost = policy.calculateCost(request);
        return BigDecimal.valueOf(cost).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }
}
