public interface DeliveryPolicy {
    boolean supports(DeliveryRequest request);
    double calculateCost(DeliveryRequest request);
}
