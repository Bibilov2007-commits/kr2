import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Locale;

public class Main {
    private final RequestParser parser = new RequestParser();
    private final DeliveryService service = new DeliveryService(new DeliveryPolicyFactory());
    private void process(BufferedReader reader, boolean interactive) throws IOException {
        String line;
        int number = 0;
        while ((line = reader.readLine()) != null) {
            number++;
            if (interactive && line.trim().equalsIgnoreCase("exit")) break;
            if (line.trim().isEmpty() || line.trim().startsWith("#")) continue;
            try {
                DeliveryRequest request = parser.parse(line);
                double cost = service.calculate(request);
                System.out.printf(Locale.ROOT, "%d | %s | %.2f руб.%n", number, request.getType(), cost);
            } catch (IllegalArgumentException ex) {
                System.out.println(number + " | Ошибка: " + ex.getMessage());
            }
        }
    }
    public static void main(String[] args) {
        Main app = new Main();
        try {
            if (args.length > 0 && args[0].equals("--interactive")) {
                System.out.println("Способы: PICKUP, STANDARD, EXPRESS, DISTANCE");
                System.out.println("Введите способ;вес_кг;расстояние_км. Выход: exit");
                app.process(new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8)), true);
            } else {
                Path path = Paths.get(args.length == 0 ? "data/sample.csv" : args[0]);
                try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                    app.process(reader, false);
                }
            }
        } catch (IOException ex) {
            System.err.println("Ошибка чтения: " + ex.getMessage());
            System.exit(1);
        }
    }
}
