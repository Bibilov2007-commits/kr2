public class SelfCheck {
    private static int count = 0;
    private static void yes(boolean value, String name) {
        if (!value) throw new AssertionError("Ошибка: " + name);
        count++;
        System.out.println("OK " + name);
    }
    private static void throwsError(Runnable action, String name) {
        boolean error = false;
        try { action.run(); } catch (IllegalArgumentException | IllegalStateException | UnsupportedOperationException e) { error = true; }
        yes(error, name);
    }
    public static void main(String[] args) {
        Employee e = new Employee("1", "Иванов Иван");
        Product a = new Product("a", "Ноутбук", 50000);
        Product b = new Product("b", "Монитор", 10000);
        OrderService service = new OrderService();
        Order o = service.createOrder(e);
        o.addProduct(a, 1);
        yes(o.total() == 50000, "Обычное добавление");
        o.addProduct(a, 2);
        yes(o.getItems().size() == 1 && o.getItems().get(0).getQuantity() == 3, "Повтор объединяется");
        o.addProduct(b, 25);
        yes(o.getItems().get(1).getQuantity() == 25, "Граница 25");
        throwsError(() -> o.addProduct(b, 1), "Превышение 25");
        throwsError(() -> o.addProduct(a, 0), "Нижняя граница 0");
        throwsError(() -> new Product("", "Товар", 100), "Пустой ID");
        throwsError(() -> new Product("c", "Товар", -1), "Отрицательная цена");
        throwsError(() -> new Product("c", "Товар", Double.NaN), "Неверная цена");
        throwsError(() -> o.addProduct(new Product("a", "Другой", 600), 1), "Конфликт ID");
        yes(o.total() == 400000, "Сумма после добавлений");
        throwsError(() -> o.getItems().clear(), "Список снаружи не изменяется");
        o.removeProduct("b");
        yes(o.total() == 150000 && o.getItems().size() == 1, "Удаление по ID");
        throwsError(() -> o.removeProduct("missing"), "Несуществующий ID");
        Order empty = service.createOrder(e);
        throwsError(() -> service.confirmOrder(empty), "Пустой заказ");
        service.confirmOrder(o);
        yes(o.isConfirmed(), "Подтверждение");
        throwsError(() -> o.addProduct(b, 1), "Запрет добавления после confirm");
        throwsError(() -> o.removeProduct("a"), "Запрет удаления после confirm");
        throwsError(() -> o.confirm(), "Повторное подтверждение");
        System.out.println("Проверок пройдено: " + count);
    }
}
