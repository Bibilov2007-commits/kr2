public class Product {
    private final String id;
    private final String name;
    private final double price;

    public Product(String id, String name, double price) {
        if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("ID товара пустой");
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Название товара пустое");
        if (!Double.isFinite(price) || price <= 0) throw new IllegalArgumentException("Цена должна быть больше 0");
        this.id = id.trim();
        this.name = name.trim();
        this.price = price;
    }
    public String getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
}
