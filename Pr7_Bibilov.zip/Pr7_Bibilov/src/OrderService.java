public class OrderService {
    public Order createOrder(Employee employee) { return new Order(employee); }
    public void validateForConfirm(Order order) {
        if (order == null) throw new IllegalArgumentException("Заказ не указан");
        if (order.getItems().isEmpty()) throw new IllegalStateException("Заказ пустой");
        if (order.isConfirmed()) throw new IllegalStateException("Заказ уже подтвержден");
    }
    public void confirmOrder(Order order) {
        validateForConfirm(order);
        order.confirm();
    }
}
