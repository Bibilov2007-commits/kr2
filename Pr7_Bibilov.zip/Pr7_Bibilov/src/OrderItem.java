public class OrderItem {
    private final Product product;
    private int quantity;

    public OrderItem(Product product, int quantity) {
        if (product == null) throw new IllegalArgumentException("Товар не указан");
        checkQuantity(quantity);
        this.product = product;
        this.quantity = quantity;
    }
    private void checkQuantity(int value) {
        if (value < 1 || value > Order.MAX_ITEM_QUANTITY) {
            throw new IllegalArgumentException("Количество должно быть от 1 до " + Order.MAX_ITEM_QUANTITY);
        }
    }
    public void increase(int more) {
        if (more < 1) throw new IllegalArgumentException("Добавляемое количество должно быть положительным");
        checkQuantity((long) quantity + more > Integer.MAX_VALUE ? Integer.MAX_VALUE : quantity + more);
        quantity += more;
    }
    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public double getLineTotal() { return product.getPrice() * quantity; }
}
