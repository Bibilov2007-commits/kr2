import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Order {
    // Вариант 4: максимальное количество единиц одного товара = 25.
    public static final int MAX_ITEM_QUANTITY = 25;
    private final Employee employee;
    private final List<OrderItem> items = new ArrayList<>();
    private boolean confirmed;

    public Order(Employee employee) {
        if (employee == null) throw new IllegalArgumentException("Сотрудник не указан");
        this.employee = employee;
    }
    public void addProduct(Product product, int quantity) {
        checkEditable();
        if (product == null) throw new IllegalArgumentException("Товар не указан");
        if (quantity < 1 || quantity > MAX_ITEM_QUANTITY) throw new IllegalArgumentException("Недопустимое количество");
        for (OrderItem item : items) {
            if (item.getProduct().getId().equals(product.getId())) {
                if (!item.getProduct().getName().equals(product.getName()) ||
                    Double.compare(item.getProduct().getPrice(), product.getPrice()) != 0) {
                    throw new IllegalArgumentException("Конфликт данных товара с одинаковым ID");
                }
                item.increase(quantity);
                return;
            }
        }
        items.add(new OrderItem(product, quantity));
    }
    public void removeProduct(String productId) {
        checkEditable();
        if (productId == null || productId.trim().isEmpty()) throw new IllegalArgumentException("ID товара пустой");
        boolean removed = items.removeIf(item -> item.getProduct().getId().equals(productId.trim()));
        if (!removed) throw new IllegalArgumentException("Товар не найден");
    }
    public double total() {
        double result = 0;
        for (OrderItem item : items) result += item.getLineTotal();
        return result;
    }
    public void confirm() {
        checkEditable();
        if (items.isEmpty()) throw new IllegalStateException("Нельзя подтвердить пустой заказ");
        confirmed = true;
    }
    private void checkEditable() {
        if (confirmed) throw new IllegalStateException("Заказ уже подтвержден");
    }
    public Employee getEmployee() { return employee; }
    public boolean isConfirmed() { return confirmed; }
    public List<OrderItem> getItems() { return Collections.unmodifiableList(items); }
}
