public class Main {
    public static void main(String[] args) {
        Employee employee = new Employee("E01", "Марат Бибилов");
        Product mouse = new Product("P01", "Мышь", 850);
        Product keyboard = new Product("P02", "Клавиатура", 1900);
        OrderService service = new OrderService();
        Order order = service.createOrder(employee);
        order.addProduct(mouse, 2);
        order.addProduct(keyboard, 1);
        order.addProduct(mouse, 3);
        System.out.println("Сотрудник: " + order.getEmployee().getFullName());
        for (OrderItem item : order.getItems()) {
            System.out.println(item.getProduct().getName() + ": " + item.getQuantity() + " шт.");
        }
        System.out.println("Итого: " + order.total() + " руб.");
        service.confirmOrder(order);
        System.out.println("Заказ подтвержден: " + order.isConfirmed());
    }
}
